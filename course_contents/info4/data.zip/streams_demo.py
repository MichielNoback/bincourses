#! /usr/local/bin/python3
import sys

# default printing to stdout
print("My input was \"", sys.stdin.readline().strip(), '"', sep = "")

# error message to stderr
print("Oh oh, we have a problem, Houston", file = sys.stderr)

# be specific about stdout
print("Ahh, solved it. Bye!", file=sys.stdout)

