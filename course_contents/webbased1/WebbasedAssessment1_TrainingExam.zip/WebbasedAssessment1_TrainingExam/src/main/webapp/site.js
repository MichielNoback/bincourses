window.onload = function () {
    //DO YOUR THING
}
